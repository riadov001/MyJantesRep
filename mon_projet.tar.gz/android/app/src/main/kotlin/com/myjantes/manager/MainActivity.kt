package com.myjantes.manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}